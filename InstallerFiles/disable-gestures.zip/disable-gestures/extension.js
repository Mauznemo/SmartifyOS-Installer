import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

export default class DisableGesturesExtension extends Extension {
    enable() {
        this._disableDemaximizingWindow = () => {
            global.stage.get_actions().forEach(a => { if (a !== this) a.enabled = false; });
        };

        global.stage.get_actions().forEach(a => a.enabled = false);

        this._focusWindowHandler = global.display.connect('notify::focus-window', this._disableDemaximizingWindow);
        this._inFullScreenChangedHandler = global.display.connect('in-fullscreen-changed', this._disableDemaximizingWindow);
    }

    disable() {
        global.stage.get_actions().forEach(a => a.enabled = true);

        if (this._focusWindowHandler) {
            global.display.disconnect(this._focusWindowHandler);
            this._focusWindowHandler = null;
        }

        if (this._inFullScreenChangedHandler) {
            global.display.disconnect(this._inFullScreenChangedHandler);
            this._inFullScreenChangedHandler = null;
        }
    }
}

